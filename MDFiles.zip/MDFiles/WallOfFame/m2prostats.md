# M2 Pro Stats

Community made M2 Pro lister by country.
Every installed and running miner will show up in these stats.

[Check it out!](http://map.mxchandbook.org)
