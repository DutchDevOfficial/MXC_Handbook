# Wall of fame

Everyone who helped this project reach its current state will be thanked in this list.

**Feedback**
* [Kirill | MatchX](https://discordapp.com/users/577804846179024896/)
* [Keith | MXC.org](https://t.me/CryptoKeith)
* [Wille_Willson](https://t.me/Wille_Willson)
* [WM](https://t.me/wiseoldman)

**Contribution**
* [Brian Allan](https://t.me/BrinerMiner) (http://www.mxcfaq.com)