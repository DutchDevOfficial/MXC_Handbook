# Procedure

What we will do is, firstly begin by answering some of the questions that have been sent in. Then once the questions have been answered we will open it up for more questions and have a round table. 

Prizes will be given out, in fact a mystery prize box! For the best questions 

Winners of the YouTube $BTC competition will be announced at the end 🎁 

So, maybe @PetyaQ  and @ifyouseeone  can start by saying "HI" to everyone and then I will start with the questions 

👋 👋
[<br><i>Keith</i>](https://t.me/CryptoKeith)