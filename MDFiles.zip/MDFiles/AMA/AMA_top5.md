# The top 5 AMA take-aways from November 2021

[Get the PDF](../../Assets/MXC_Extra/AMA_Takeaway_Nov2020.pdf)

![MXC](../../Assets/MXC_Extra/AMA_Takeaway-Nov2020.jpg)