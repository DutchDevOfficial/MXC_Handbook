# Cinema

## What is LPWAN?

<iframe height="350" src="https://www.youtube.com/embed/JOXZC6Qgnr0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<!-- [![LPWAN](https://img.youtube.com/vi/JOXZC6Qgnr0/0.jpg)](https://www.youtube.com/watch?v=JOXZC6Qgnr0) -->

## How to install the M2 Pro?

<iframe height="350" src="https://www.youtube.com/embed/2nOUdLNJVtU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<!-- [![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/2nOUdLNJVtU/0.jpg)](https://www.youtube.com/watch?v=2nOUdLNJVtU) -->
