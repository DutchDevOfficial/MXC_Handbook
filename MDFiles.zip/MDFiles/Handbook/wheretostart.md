Welcome to MXC! 👋
MXC is powering the future of Data, Edge AI and we’re building a global data network using the MXC token! ⚡️

Where can I read more about MXC? 🤓
• In MXC’s Whitepaper(s) aka all you need to know: 
https://www.mxc.org/mxc-token

Is MXC an Exchange? 🤔
• No, we are not, we are a leading Data Token, please check out more on https://www.MXC.org/ 
We are the only and original MXC!

• Where can I find MXC on CMC? 🪙 
https://www.coingecko.com/en/coins/mxc

Can you tell me more about the M2 Pro Crypto Miner? 

• Earnings Estimate: https://medium.com/mxc/m2-pro-the-worlds-preferred-iot-miner-31ccf9921fd5

• FAQ: 
https://medium.com/mxc/m2-pro-miner-faq-c6b4e8e60ab9 

• M2 Pro Technical Specifications Details:
https://www.matchx.io/wp-content/uploads/2020/09/M2_Pro_Compressed_ENG.pdf 

• M2 Pro 3rd Party Review:
https://www.youtube.com/watch?v=qO6VI9CkhWo&t 

• Where to buy the M2 Pro:
https://www.matchx.io/m2pro/ 

• How to install the M2 Pro in 4 minutes:
https://www.youtube.com/watch?v=2nOUdLNJVtU&t 
 
Where can I view this Global Data Network live? 🌎
https://mxcmapper.com/ 

What do I need the DataDash App for? 
 • You can synchronize your Miner on the DataDash App to earn $BTC, $DHX and $MXC Token, or you can simply stake your tokens to earn more!

Where can I download  the DataDash App? 📱
https://www.mxc.org/mxcdatadash 
 
Where else can I follow you? 

Twitter: https://twitter.com/MXCfoundation 

Discord: https://discord.com/invite/4vrJyhXs