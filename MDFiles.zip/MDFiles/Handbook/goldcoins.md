# The guide to use the golden coin by Kirill: 

**Step 1:** Open your internet browser and go to [regcoin.mxc.org](regcoin.mxc.org)

**Step 2:** Enter your name and your email address. Complete the Captcha and click Submit

**Step 3:** Check your email inbox and click the link from MXC

**Step 4:** Enter the code from your metal coin and your MXC Wallet address.

**Step 5:** Your MXC will be transmitted to your wallet (may take up to 14-days)

**Step 6:** Pour some refreshments and enjoy the day 😉🍹