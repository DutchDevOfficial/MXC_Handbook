**Use promocode: 'MXC125' to get you 50 euros off every M2**

[BUY HERE](https://www.matchx.io/product/m2-pro-lpwan-crypto-miner/)

![MXC](../../Assets/promo/example.jpg)