![logo](/Assets/Logo/Logo_fit.png)

# The MXC Handbook <small>V1</small>

> MXC all in one community guide

- Step by step
- By the community for the community
- All in one

[AMA](/MDFiles/AMA/AMA)
[Handbook](/MDFiles/Handbook/handbook)


